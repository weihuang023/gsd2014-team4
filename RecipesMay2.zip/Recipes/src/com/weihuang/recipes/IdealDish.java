package com.weihuang.recipes;

public class IdealDish {

}
